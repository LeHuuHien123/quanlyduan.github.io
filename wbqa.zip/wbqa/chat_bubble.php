<style>
    /* 1. WRAPPER & BONG BÓNG */
    #global-chat-wrapper { position: fixed; bottom: 20px; right: 20px; z-index: 9999999; font-family: 'Rajdhani', sans-serif; }
    #chat-bubble-trigger {
        width: 60px; height: 60px; background: linear-gradient(135deg, #ffcc00, #ff9900);
        border-radius: 50%; display: flex; justify-content: center; align-items: center;
        cursor: pointer; box-shadow: 0 8px 32px rgba(255, 204, 0, 0.3); border: 2px solid #fff; position: relative;
    }

    /* 2. CHẤM ĐỎ THÔNG BÁO */
    #chat-badge { display: none; position: absolute; top: -5px; right: -5px; background: #ff0000; color: white; border-radius: 50%; padding: 2px 7px; font-size: 11px; font-weight: bold; border: 2px solid #fff; z-index: 100; }

    /* 3. KHUNG CỬA SỔ CHAT */
    #chat-window-box {
        position: absolute; bottom: 75px; right: 0; width: 380px; height: 520px;
        background: radial-gradient(circle at top, #1a1a2e, #0f0f1a);
        border: 1px solid rgba(255, 204, 0, 0.5); border-radius: 20px;
        display: none; flex-direction: column; box-shadow: 0 15px 40px rgba(0,0,0,0.6); 
        overflow: hidden; backdrop-filter: blur(10px);
    }

    .chat-win-header { background: #ffcc00; color: #000; padding: 12px 15px; display: flex; justify-content: space-between; align-items: center; font-weight: 900; flex-shrink: 0; }

    /* 4. ADMIN LAYOUT & SIDEBAR */
    .admin-layout { display: flex; flex: 1; width: 100%; overflow: hidden; }
    .user-sidebar { width: 95px; border-right: 1px solid rgba(255,255,255,0.1); overflow-y: auto; background: rgba(0,0,0,0.2); flex-shrink: 0; }
    .user-item { padding: 12px 5px; text-align: center; border-bottom: 1px solid rgba(255,255,255,0.05); cursor: pointer; color: #fff; font-size: 10px; transition: 0.3s; }
    
    /* MÀU SIDEBAR ADMIN */
    .user-item.waiting { color: #ffcc00 !important; font-weight: bold; text-shadow: 0 0 5px rgba(255, 204, 0, 0.3); }
    .user-item.replied { color: rgba(255, 255, 255, 0.5) !important; }
    .user-item.active { background: #ffcc00 !important; color: #000 !important; }

    .admin-main-chat { flex: 1; display: flex; flex-direction: column; min-width: 0; }
    .chat-win-body { flex: 1; padding: 15px; overflow-y: auto; display: flex; flex-direction: column; gap: 12px; }
    .chat-win-footer { padding: 10px; background: rgba(0,0,0,0.3); border-top: 1px solid rgba(255,255,255,0.05); display: flex; gap: 5px; flex-shrink: 0; }
    .chat-win-footer input { flex: 1; background: rgba(255,255,255,0.05); border: 1px solid rgba(255,255,255,0.2); color: #fff; padding: 10px; border-radius: 20px; outline: none; }
    .btn-send { background: #ffcc00; border: none; padding: 5px 15px; border-radius: 20px; cursor: pointer; font-weight: bold; }

    .msg-bot-style { background: rgba(255, 255, 255, 0.1); padding: 10px 14px; border-radius: 15px 15px 15px 0; color: #efefef; font-size: 13px; align-self: flex-start; max-width: 85%; }
    .msg-user-style { background: linear-gradient(135deg, #ffcc00, #f39c12); color: #000; padding: 10px 14px; border-radius: 15px 15px 0 15px; font-size: 13px; align-self: flex-end; font-weight: 600; max-width: 85%; }

    @media screen and (max-width: 768px) { #chat-window-box { width: 90vw; height: 65vh; right: 5vw; } }
</style>

<audio id="notif-sound" crossorigin="anonymous" preload="auto">
    <source src="https://assets.mixkit.co/active_storage/sfx/2358/2358-preview.mp3" type="audio/mpeg">
</audio>

<div id="global-chat-wrapper">
    <div id="chat-bubble-trigger" onclick="handleToggleChat()">
        <img src="https://cdn-icons-png.flaticon.com/512/5962/5962463.png" width="30">
        <span id="chat-badge">0</span>
    </div>

    <div id="chat-window-box">
        <div class="chat-win-header">
            <span>HỖ TRỢ <?php echo (isset($_SESSION['role']) && $_SESSION['role'] == 'admin') ? 'ADMIN' : '24/7'; ?></span>
            <button onclick="handleToggleChat()" style="background:none; border:none; cursor:pointer; font-weight:bold;">×</button>
        </div>

        <?php if (isset($_SESSION['role']) && $_SESSION['role'] == 'admin'): ?>
            <div class="admin-layout">
                <div id="user-list" class="user-sidebar"></div>
                <div class="admin-main-chat">
                    <div style="padding:5px; background:#16162d; font-size:11px; color:#ffcc00;">Đang chat: <span id="target-name">...</span></div>
                    <div id="admin-chat-body" class="chat-win-body"></div>
                    <div class="chat-win-footer">
                        <input type="text" id="admin-input" placeholder="Trả lời..." onkeypress="if(event.keyCode==13) handleAdminSend()">
                        <button class="btn-send" onclick="handleAdminSend()">➤</button>
                    </div>
                    <button onclick="handleEndChat()" style="background:#e74c3c; color:#fff; border:none; padding:5px; font-size:10px; cursor:pointer;">HỦY ĐOẠN CHÁT</button>
                </div>
            </div>
        <?php else: ?>
            <div id="chat-win-body" class="chat-win-body"></div>
            <div class="chat-win-footer">
                <input type="text" id="chat-input-field" placeholder="Nhập tin nhắn..." onkeypress="if(event.keyCode==13) handleSendChat()">
                <button class="btn-send" onclick="handleSendChat()">➤</button>
            </div>
        <?php endif; ?>
    </div>
</div>

<script>
    let target_id = null;
    let lastAdminMsgCount = 0; 
    let lastTotalWaiting = 0;

    function handleToggleChat() {
        const box = document.getElementById('chat-window-box');
        const badge = document.getElementById('chat-badge');
        if (box.style.display === "none" || box.style.display === "") {
            box.style.display = "flex";
            badge.style.display = "none";
            <?php if(isset($_SESSION['role']) && $_SESSION['role'] == 'admin'): ?>
                loadUserList();
            <?php else: ?>
                loadMessages();
            <?php endif; ?>
        } else {
            box.style.display = "none";
            if(lastTotalWaiting > 0) { badge.style.display = "block"; badge.innerText = lastTotalWaiting; }
        }
    }

    function loadUserList() {
        fetch('admin_actions.php?action=get_waiting_list').then(res => res.text()).then(data => {
            const list = document.getElementById('user-list');
            const badge = document.getElementById('chat-badge');
            const box = document.getElementById('chat-window-box');
            if(list) {
                const temp = document.createElement('div'); temp.innerHTML = data;
                const waitingItems = temp.querySelectorAll('.user-item.waiting');
                let currentWaiting = waitingItems.length;
                if(currentWaiting > lastTotalWaiting && lastTotalWaiting !== 0) playNotif();
                if(currentWaiting > 0 && (box.style.display === "none" || box.style.display === "")) {
                    badge.innerText = currentWaiting; badge.style.display = "block";
                }
                lastTotalWaiting = currentWaiting; list.innerHTML = data;
            }
        });
    }

    function selectUser(id, name) {
        target_id = id;
        document.getElementById('target-name').innerText = name;
        document.querySelectorAll('.user-item').forEach(i => i.classList.remove('active'));
        loadAdminMessages();
    }

    function loadAdminMessages() {
        if(!target_id) return;
        fetch('load_chat.php?target_id=' + target_id).then(res => res.text()).then(data => {
            const body = document.getElementById('admin-chat-body');
            if(body) { body.innerHTML = data; body.scrollTop = body.scrollHeight; }
        });
    }

    function handleAdminSend() {
        const input = document.getElementById('admin-input');
        const msg = input.value.trim();
        if(msg !== "" && target_id !== null) {
            fetch('save_chat.php', { method: 'POST', headers: { 'Content-Type': 'application/x-www-form-urlencoded' }, body: 'message=' + encodeURIComponent(msg) + '&target_user_id=' + target_id })
            .then(() => { input.value = ""; loadAdminMessages(); loadUserList(); });
        }
    }

    function loadMessages() {
        fetch('load_chat.php').then(res => res.text()).then(data => {
            const body = document.getElementById('chat-win-body');
            const badge = document.getElementById('chat-badge');
            const box = document.getElementById('chat-window-box');
            if(body) {
                const temp = document.createElement('div'); temp.innerHTML = data;
                const currentAdminMsgs = temp.querySelectorAll('.msg-bot-style').length;
                if(currentAdminMsgs > lastAdminMsgCount && lastAdminMsgCount !== 0) {
                    playNotif();
                    if(box.style.display === "none" || box.style.display === "") { badge.innerText = "!"; badge.style.display = "block"; }
                }
                lastAdminMsgCount = currentAdminMsgs; body.innerHTML = data;
                body.scrollTop = body.scrollHeight;
            }
        });
    }

    function handleSendChat() {
        const input = document.getElementById('chat-input-field');
        const msg = input.value.trim();
        if(msg !== "") {
            fetch('save_chat.php', { method: 'POST', headers: { 'Content-Type': 'application/x-www-form-urlencoded' }, body: 'message=' + encodeURIComponent(msg) })
            .then(() => { input.value = ""; loadMessages(); });
        }
    }

    function playNotif() {
        const sound = document.getElementById('notif-sound');
        if (sound) { sound.currentTime = 0; sound.play().catch(() => {}); }
    }

    <?php if(isset($_SESSION['role']) && $_SESSION['role'] == 'admin'): ?>
        loadUserList(); setInterval(loadUserList, 5000); setInterval(loadAdminMessages, 3000);
    <?php else: ?>
        setInterval(loadMessages, 3000);
    <?php endif; ?>
</script>