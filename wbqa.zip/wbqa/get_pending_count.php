<?php
include 'datk.php';
$result = mysqli_query($conn, "SELECT COUNT(*) as total FROM bookings WHERE status = 'pending'");
$row = mysqli_fetch_assoc($result);
echo $row['total'];
?>