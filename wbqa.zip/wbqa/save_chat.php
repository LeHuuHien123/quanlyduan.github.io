<?php
session_start();
$host = 'localhost'; $user = 'root'; $pass = ''; $db = 'golden_feast_db';
$conn = new mysqli($host, $user, $pass, $db);
mysqli_set_charset($conn, "utf8mb4");

if (isset($_POST['message'])) {
    $msg = $conn->real_escape_string($_POST['message']);

    // KIỂM TRA: NẾU LÀ ADMIN ĐANG NHẮN (Gửi từ trang quản trị)
    if (isset($_SESSION['role']) && $_SESSION['role'] == 'admin') {
        $username = "Quản lý Nhà Hàng"; // Tên hiển thị của ông
        $type = 'admin';
        // Admin nhắn cho khách nào thì phải lấy ID của khách đó từ form gửi lên
        $user_id = isset($_POST['target_user_id']) ? intval($_POST['target_user_id']) : 0;
    } 
    // NGƯỢC LẠI: NẾU LÀ KHÁCH ĐANG NHẮN (Gửi từ web)
    else {
        // Lấy tên thật từ database (fullname trong ảnh image_8d69c4.png)
        $username = isset($_SESSION['fullname']) ? $_SESSION['fullname'] : 'Khách vãng lai';
        $type = 'user';
        // ID của chính người khách đang đăng nhập
        $user_id = isset($_SESSION['user_id']) ? intval($_SESSION['user_id']) : 0;
    }

    // LƯU VÀO SQL (Theo cấu trúc ảnh image_8d69bb.png)
    $sql = "INSERT INTO chat_messages (user_id, username, message, type, status) 
            VALUES ('$user_id', '$username', '$msg', '$type', 'new')";
    
    if ($conn->query($sql) === TRUE) {
        echo "Gửi thành công!";
    }
}
$conn->close();
?>