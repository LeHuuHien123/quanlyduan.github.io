<?php
session_start();
$host = 'localhost'; $user = 'root'; $pass = ''; $db = 'golden_feast_db';
$conn = new mysqli($host, $user, $pass, $db);
mysqli_set_charset($conn, "utf8mb4");

// 1. XÁC ĐỊNH ĐỐI TƯỢNG CẦN LOAD TIN NHẮN
$target_user_id = 0;

// Nếu là Admin đang xem một khách cụ thể (truyền qua URL: load_chat.php?target_id=...)
if (isset($_SESSION['role']) && $_SESSION['role'] == 'admin') {
    $target_user_id = isset($_GET['target_id']) ? intval($_GET['target_id']) : 0;
} 
// Nếu là Khách đang xem chat của chính mình
else {
    $target_user_id = isset($_SESSION['user_id']) ? intval($_SESSION['user_id']) : 0;
}

if ($target_user_id > 0) {
    // Lấy thêm trường time_only
    $sql = "SELECT *, DATE_FORMAT(created_at, '%H:%i') as time_only 
            FROM chat_messages 
            WHERE user_id = '$target_user_id' 
            ORDER BY id ASC";
            
    $result = $conn->query($sql);
    if ($result->num_rows > 0) {
        while($row = $result->fetch_assoc()) {
            $class = ($row['type'] == 'admin') ? 'msg-bot-style' : 'msg-user-style';
            echo '<div class="'.$class.'">';
            echo '<strong>'.$row['username'].':</strong> '.$row['message'];
            // Hiện giờ nhắn tin nhỏ ở dưới
            echo '<span class="msg-time" style="display:block; font-size:9px; opacity:0.5; margin-top:4px;">'.$row['time_only'].'</span>';
            echo '</div>';
        }
    } else {
        echo '<div class="msg-bot-style">Chưa có tin nhắn nào trong cuộc hội thoại này.</div>';
    }
} else {
    echo '<div class="msg-bot-style">Vui lòng chọn một khách hàng để xem tin nhắn.</div>';
}
$conn->close();
?>