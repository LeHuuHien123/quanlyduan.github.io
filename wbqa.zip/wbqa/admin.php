<?php
session_start();
include 'php/datk.php'; 
// Kiểm tra: Nếu không phải admin VÀ cũng không phải staff thì đá ra trang chủ
if (!isset($_SESSION['role']) || ($_SESSION['role'] !== 'admin' && $_SESSION['role'] !== 'staff')) {
    header("Location: index.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <title>Quản trị Shop Quần Áo</title>
    <link rel="stylesheet" href="css/dungchung.css">
    <link rel="stylesheet" href="css/admin.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>
<body>
    <div class="admin-container">
        <aside class="sidebar">
            <a href="index.php" class="logo">
                <img src="img/logo/1.png" alt="Fashion Shop" style="height: 100px; width: 100px; object-fit: contain;">
            </a>
            <ul class="menu">
                <li class="menu-item active" onclick="showTab(event, 'dashboard')"><i class="fa-solid fa-chart-line"></i> Báo Cáo</li>
                <li class="menu-item" onclick="showTab(event, 'users')"><i class="fa-solid fa-users"></i> Khách Hàng</li>
                <li class="menu-item" onclick="showTab(event, 'products')"><i class="fa-solid fa-shirt"></i> Sản Phẩm</li>
                <li class="menu-item" onclick="showTab(event, 'orders')">
                    <i class="fa-solid fa-cart-shopping"></i> Đơn Hàng
                    <?php
                        $count_res = mysqli_query($conn, "SELECT COUNT(*) as total FROM orders WHERE status = 'waiting_confirm'");
                        $count_data = mysqli_fetch_assoc($count_res);
                        if($count_data['total'] > 0) echo "<span class='nav-counter'>{$count_data['total']}</span>";
                    ?>
                </li>
                <li class="nav-item logout-item">
                    <a href="php/logout.php" class="nav-link logout-link">
                        <i class="fa-solid fa-right-from-bracket"></i>
                        <span>Đăng xuất</span>
                    </a>
                </li>
                            </ul>
        </aside>

        <main class="main-content">
            <section id="dashboard" class="tab-content active">
                <div class="admin-header">
                    <h3>Hệ Thống Báo Cáo Doanh Thu</h3>
                    <div class="filter-box">
                        <input type="date" id="filterDate" class="status-select">
                        <button class="btn-main" onclick="updateCharts()"><i class="fa-solid fa-filter"></i> Lọc</button>
                    </div>
                </div>

                <div class="stat-grid">
                    <div class="stat-card">
                        <i class="fa-solid fa-sack-dollar" style="color: #e67e22;"></i>
                        <div class="stat-title">Doanh thu tháng này</div>
                        <div class="stat-number" id="stat-revenue">0đ</div>
                    </div>
                    <div class="stat-card">
                        <i class="fa-solid fa-box-open" style="color: #3498db;"></i>
                        <div class="stat-title">Sản phẩm đã bán</div>
                        <div class="stat-number" id="stat-sold">0</div>
                    </div>
                </div>

                <div style="display: grid; grid-template-columns: 2fr 1fr; gap: 20px; margin-top: 20px;">
                    <div class="table-container">
                        <canvas id="barChart"></canvas>
                    </div>
                    <div class="table-container">
                        <canvas id="pieChart"></canvas>
                    </div>
                </div>
            </section>

           <section id="users" class="tab-content">
                <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px;">
                    <h3>Quản Lý Khách Hàng</h3>
                    <button class="btn-main" onclick="openUserModal()"><i class="fa-solid fa-plus"></i> Thêm Khách Hàng</button>
                </div>
                <table>
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Họ Tên</th>
                            <th>Email</th>
                            <th>Vai trò</th>
                            <th>Thao tác</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        // Lấy danh sách người dùng, sắp xếp ID mới nhất lên đầu
                        $userRes = mysqli_query($conn, "SELECT * FROM users ORDER BY id DESC");
                        while ($row = mysqli_fetch_assoc($userRes)) {
                            $userJson = htmlspecialchars(json_encode($row), ENT_QUOTES, 'UTF-8');
                            
                            // Xác định màu sắc Badge
                            $roleBadge = 'badge-user';
                            if ($row['role'] == 'admin') $roleBadge = 'badge-admin';
                            else if ($row['role'] == 'staff') $roleBadge = 'badge-staff';

                            // QUAN TRỌNG: Phải có data-user-id='{$row['id']}'
                            echo "<tr data-user-id='{$row['id']}'>
                                    <td>#{$row['id']}</td>
                                    <td class='u-name'>" . (!empty($row['fullname']) ? htmlspecialchars($row['fullname']) : "<i style='color:gray'>(Trống)</i>") . "</td>
                                    <td class='u-email'>" . (!empty($row['email']) ? htmlspecialchars($row['email']) : "---") . "</td>
                                    <td><span class='badge {$roleBadge}'>" . strtoupper($row['role']) . "</span></td>
                                    <td>
                                        <button class='btn-edit' title='Sửa' onclick='editUser({$userJson})'>
                                            <i class='fa-solid fa-pen'></i>
                                        </button>";

                            // Chỉ hiện nút xóa nếu tài khoản không phải Admin
                            if ($row['role'] !== 'admin') {
                                echo " <button class='btn-danger' 
                                            style='background: #ff4757; color: white; border: none; padding: 8px 15px; border-radius: 5px; cursor: pointer; margin-left: 5px;' 
                                            onclick='deleteUser({$row['id']})'>
                                            <i class='fa-solid fa-trash'></i> Xóa
                                        </button>";
                            }

                            echo "  </td>
                                </tr>";
                        }
                        ?>
                    </tbody>
                </table>
            </section>

            <section id="products" class="tab-content">
                <div style="display:flex; justify-content: space-between; align-items: center; margin-bottom: 20px;">
                    <h3>Quản Lý Sản Phẩm</h3>
                    <button class="btn-main" onclick="openProductModal()"><i class="fa-solid fa-plus"></i> Thêm Sản Phẩm</button>
                </div>
                <table>
                    <thead>
                        <tr><th>Ảnh</th><th>Tên</th><th>Danh Mục</th><th>Size</th><th>Giá</th><th>Tồn</th><th>Thao tác</th></tr>
                    </thead>
                    <tbody>
                        <?php
                        $prodRes = mysqli_query($conn, "SELECT * FROM products ORDER BY id DESC");
                        while ($row = mysqli_fetch_assoc($prodRes)) {
                            $imgArr = explode(',', $row['image']);
                            $prodJson = htmlspecialchars(json_encode($row), ENT_QUOTES, 'UTF-8');
                            echo "<tr data-id='{$row['id']}'>
                                <td><img src='{$imgArr[0]}' style='width:40px; height:50px; object-fit:cover; border-radius:4px;'></td>
                                <td class='p-name'>{$row['product_name']}</td>
                                <td class='p-cat'>{$row['category']}</td>
                                <td class='p-size' style='font-size:11px;'>{$row['size']}</td>
                                <td class='p-price'>".number_format($row['price'])."đ</td>
                                <td class='p-stock'>{$row['stock']}</td>
                                <td>
                                    <button class='btn-edit' onclick='editProduct({$prodJson})'><i class='fa-solid fa-pen'></i></button>
                                    <button class='btn-delete' onclick='deleteProduct({$row['id']})'><i class='fa-solid fa-trash'></i></button>
                                </td>
                            </tr>";
                        }
                        ?>
                    </tbody>
                </table>
            </section>

            <section id="orders" class="tab-content">
                <h3>Quản Lý Đơn Hàng</h3>
                <table>
                    <thead>
                        <tr><th>Mã</th><th>Ngày Đặt</th><th>Khách Hàng</th><th>Tổng Tiền</th><th>PTTT</th><th>Trạng Thái</th><th>Chi tiết</th></tr>
                    </thead>
                    <tbody>
                        <?php
                        $sql_grouped = "SELECT u.fullname, o.phone, o.address, o.status, o.payment_method, 
                                            MIN(o.created_at) as order_date, SUM(o.total_price) as grand_total, 
                                            GROUP_CONCAT(o.id) as list_ids 
                                        FROM orders o 
                                        JOIN users u ON o.user_id = u.id 
                                        WHERE o.status != 'pending' 
                                        GROUP BY u.fullname, o.phone, o.address, o.status, o.payment_method 
                                        ORDER BY MIN(o.id) DESC";
                        $orderRes = mysqli_query($conn, $sql_grouped);
                        
                        while ($o = mysqli_fetch_assoc($orderRes)) {
                            $group_id = explode(',', $o['list_ids'])[0];
                        ?>
                            <tr>
                                <td>
                                    <?php 
                                    // Tạo mã đơn giống hệt bên trang Cart: DH-NgàyThángNăm-GiờPhút-ID
                                    $order_code = "DH-" . date("dmy-Hi", strtotime($o['order_date'])) . "-" . $group_id;
                                    echo "<strong>" . $order_code . "</strong>";
                                    ?>
                                </td>
                                <td style="font-size: 12px;"><?= date('d/m H:i', strtotime($o['order_date'])) ?></td>
                                <td><?= htmlspecialchars($o['fullname']) ?></td>
                                <td style="color: #e67e22; font-weight:bold;"><?= number_format($o['grand_total']) ?>đ</td>
                                <td><?= ($o['payment_method'] == 'banking') ? 'CK' : 'COD' ?></td>
                                <td>
                                    <select class="status-select" 
                                            onchange="updateGroupStatus('<?= $o['list_ids'] ?>', this.value, this)" 
                                            style="background: <?= ($o['status'] == 'delivered') ? '#d4edda' : '#fff' ?>;">
                                        <option value="waiting_confirm" <?= $o['status'] == 'waiting_confirm' ? 'selected' : '' ?>>⏳ Chờ duyệt</option>
                                        <option value="confirmed" <?= $o['status'] == 'confirmed' ? 'selected' : '' ?>>✅ Xác nhận</option>
                                        <option value="shipped_to_hub" <?= $o['status'] == 'shipped_to_hub' ? 'selected' : '' ?>>📦 Gửi kho</option>
                                        <option value="in_transit" <?= $o['status'] == 'in_transit' ? 'selected' : '' ?>>🚚 Đang giao</option>
                                        <option value="delivered" <?= $o['status'] == 'delivered' ? 'selected' : '' ?>>🏁 Hoàn tất</option>
                                        <option value="cancelled" <?= $o['status'] == 'cancelled' ? 'selected' : '' ?>>❌ Hủy</option>
                                    </select>
                                </td>
                                <td>
                                    <button onclick="toggleDetails('details-<?= $group_id ?>')" class="btn-edit"><i class="fa-solid fa-eye"></i></button>
                                    <button class="btn-delete" onclick="deleteOrderGroup('<?= $o['list_ids'] ?>')"><i class="fa-solid fa-trash"></i></button>
                                </td>
                            </tr>

                           <tr id="details-<?= $group_id ?>" style="display: none; background: #f9f9f9;">
                                <td colspan="7">
                                    <div style="padding: 15px; border-left: 5px solid #e67e22; text-align: left;">
                                        <p><strong>🆔 Mã đơn hàng:</strong> DH-<?= date("dmy-Hi", strtotime($o['order_date'])) ?>-<?= $group_id ?></p>
                                        <p><strong>📍 Địa chỉ:</strong> <?= htmlspecialchars($o['address']) ?></p>
                                        <hr style="margin: 10px 0; border: 0.2px solid #eee;">
                                        <strong>🛒 Sản phẩm:</strong>
                                        <table style="width: 100%; margin-top: 5px;">
                                            <?php
                                            $sub_ids = $o['list_ids'];
                                            $sql_sub = "SELECT p.product_name, o.quantity, o.total_price 
                                                        FROM orders o JOIN products p ON o.product_id = p.id 
                                                        WHERE o.id IN ($sub_ids)";
                                            $res_sub = mysqli_query($conn, $sql_sub);
                                            while($item = mysqli_fetch_assoc($res_sub)) {
                                                echo "<tr>
                                                        <td>• {$item['product_name']}</td>
                                                        <td>x{$item['quantity']}</td>
                                                        <td align='right'>".number_format($item['total_price'])."đ</td>
                                                    </tr>";
                                            }
                                            ?>
                                        </table>
                                    </div>
                                </td>
                            </tr>
                        <?php } ?>
                    </tbody>
                </table>
            </section>
        </main>
    </div>

    <div id="productModal" class="modal">
        <div class="modal-content">
            <h3 id="modalTitle">Thông Tin Sản Phẩm</h3>
            <form id="productForm">
                <input type="hidden" id="prodId" name="id">
                <div class="form-group">
                    <label>Tên sản phẩm</label>
                    <input type="text" id="prodName" name="product_name" required>
                </div>
                <div class="form-group">
                    <label>Danh mục</label>
                    <select id="prodCategory" name="category">
                        <option value="Áo">Áo</option><option value="Quần">Quần</option><option value="Áo Khoác">Áo Khoác</option><option value="Phụ Kiện">Phụ Kiện</option>
                    </select>
                </div>
                <div style="display: flex; gap: 10px;">
                    <div class="form-group" style="flex:1">
                        <label>Giá bán</label>
                        <input type="number" id="prodPrice" name="price" required>
                    </div>
                    <div class="form-group" style="flex:1">
                        <label>Size (VD: S:10,M:5)</label>
                        <input type="text" id="prodSize" name="size" required>
                    </div>
                </div>
                <div class="form-group">
                    <label>Link ảnh (cách nhau dấu phẩy)</label>
                    <textarea id="prodImg" name="image" rows="2"></textarea>
                </div>
                <div class="form-group">
                    <label>Mô tả sản phẩm</label>
                    <textarea id="prodDesc" name="description" rows="3"></textarea>
                </div>
                <div class="btn-group">
                    <button type="button" style="color: rgb(255, 255, 255);
                                                font-weight: 600;
                                                cursor: pointer;
                                                background: var(--primary);
                                                padding: 12px 28px;
                                                border-radius: 10px;
                                                border-width: initial;
                                                border-style: none;
                                                border-color: initial;
                                                border-image: initial;
                                                transition: var(--transition);" 
                    class="btn-secondary" onclick="closeProductModal()">Hủy</button>
                    <button type="submit" class="btn-main">Lưu dữ liệu</button>
                </div>
            </form>
        </div>
    </div>

    <div id="userModal" class="modal">
        <div class="modal-content">
            <h3>Thông Tin Khách Hàng</h3>
            <form id="userForm">
                <input type="hidden" id="userId" name="id">
                
                <div class="form-group">
                    <label>Họ Tên</label>
                    <input type="text" id="userName" name="fullname" required>
                </div>
                
                <div class="form-group">
                    <label>Email</label>
                    <input type="email" id="userEmail" name="email" required>
                </div>

                <?php if ($_SESSION['role'] === 'admin'): ?>
                <div class="form-group">
                    <label>Vai trò hệ thống</label>
                    <select id="userRole" name="role" class="status-select" style="width: 100%; padding: 10px; border-radius: 8px;">
                        <option value="user">USER (Khách hàng)</option>
                        <option value="staff">STAFF (Nhân viên)</option>
                        <option value="admin">ADMIN (Quản trị viên)</option>
                    </select>
                </div>
                <?php else: ?>
                    <input type="hidden" id="userRole" name="role" value="user">
                <?php endif; ?>

                <div class="form-group">
                    <label>Mật khẩu</label>
                    <input type="password" id="userPass" name="password" placeholder="Bỏ trống nếu không đổi">
                </div>

                <div class="btn-group">
                    <button type="button" class="btn-secondary" onclick="closeUserModal()" 
                        style="color: white; font-weight: 600; cursor: pointer; background: #6c757d; padding: 12px 28px; border-radius: 10px; border: none;">
                        Đóng
                    </button>
                    <button type="submit" class="btn-main">Cập nhật</button>
                </div>
            </form>
        </div>
    </div>
    </div>

    <script>
        function showTab(event, tabId) {
            document.querySelectorAll('.tab-content').forEach(c => c.classList.remove('active'));
            document.querySelectorAll('.sidebar .menu li').forEach(l => l.classList.remove('active'));
            document.getElementById(tabId).classList.add('active');
            event.currentTarget.classList.add('active');
        }
        function toggleDetails(id) {
            const el = document.getElementById(id);
            el.style.display = (el.style.display === 'none') ? 'table-row' : 'none';
        }
    </script>
    <script src="js/admin.js?v=<?php echo time(); ?>"></script>
</body>
</html>