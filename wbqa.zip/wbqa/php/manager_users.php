<?php
session_start();
// Bật hiển thị lỗi để dễ tìm nguyên nhân
ini_set('display_errors', 1);
error_reporting(E_ALL);

include 'datk.php'; 

if (!$conn) {
    die("Lỗi kết nối database: " . mysqli_connect_error());
}

// Lấy action từ FormData gửi sang
$action = $_POST['action'] ?? '';

if ($action === 'save') {
    $id = isset($_POST['id']) ? intval($_POST['id']) : 0;
    $fullname = mysqli_real_escape_string($conn, $_POST['fullname']);
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $role = mysqli_real_escape_string($conn, $_POST['role'] ?? 'user');
    $password = $_POST['password'] ?? '';

    if ($id > 0) {
        // CẬP NHẬT (SỬA)
        $updateFields = "fullname='$fullname', email='$email', role='$role'";
        if (!empty($password)) {
            // Dùng md5 hoặc password_hash tùy theo file login.php của bạn
            // Ở đây dùng password_hash (yêu cầu cột password trong DB dài 255 ký tự)
            $hashed_pass = password_hash($password, PASSWORD_DEFAULT);
            $updateFields .= ", password='$hashed_pass'";
        }
        $sql = "UPDATE users SET $updateFields WHERE id = $id";
    } else {
        // THÊM MỚI
        if (empty($password)) {
            echo "Mật khẩu là bắt buộc khi thêm mới!";
            exit;
        }
        $hashed_pass = password_hash($password, PASSWORD_DEFAULT);
        $sql = "INSERT INTO users (fullname, email, password, role) VALUES ('$fullname', '$email', '$hashed_pass', '$role')";
    }

    if (mysqli_query($conn, $sql)) {
        echo "success";
    } else {
        echo "Lỗi SQL: " . mysqli_error($conn);
    }
    exit; // Quan trọng: Dừng chương trình tại đây nếu đã xong action save
}

// Nếu gửi action delete
if ($action === 'delete') {
    $id = intval($_POST['id']);
    if (mysqli_query($conn, "DELETE FROM users WHERE id = $id")) {
        echo "success";
    } else {
        echo "Lỗi xóa: " . mysqli_error($conn);
    }
    exit;
}

// Chỉ hiện dòng này nếu KHÔNG vào các if ở trên
echo "Yêu cầu không hợp lệ! Action nhận được: " . $action;
?>