<?php
// Thông tin cấu hình
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "shop"; // Tên database khớp với hình ảnh phpMyAdmin bạn cung cấp

// Tạo kết nối
$conn = mysqli_connect($servername, $username, $password, $dbname);

// Kiểm tra kết nối
if (!$conn) {
    die("Kết nối thất bại: " . mysqli_connect_error());
}

// Thiết lập font chữ tiếng Việt cho database
mysqli_set_charset($conn, "utf8");
?>