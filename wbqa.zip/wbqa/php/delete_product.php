<?php
session_start();
include 'datk.php';

if (isset($_GET['id'])) {
    $id = (int)$_GET['id'];
    
    // Xóa các đơn hàng có chứa sản phẩm này trước để tránh lỗi Khóa ngoại (Foreign Key)
    mysqli_query($conn, "DELETE FROM orders WHERE product_id = $id");
    
    // Sau đó mới xóa sản phẩm
    $sql = "DELETE FROM products WHERE id = $id";
    if (mysqli_query($conn, $sql)) {
        echo "success";
    } else {
        echo "Lỗi SQL: " . mysqli_error($conn);
    }
}
?>