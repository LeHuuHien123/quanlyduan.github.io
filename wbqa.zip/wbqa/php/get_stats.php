<?php
include 'datk.php'; // File kết nối database của bạn
header('Content-Type: application/json');

// Nhận tham số ngày từ giao diện (nếu có)
$filterDate = isset($_GET['date']) ? $_GET['date'] : null;

$response = [
    'stats' => ['revenue' => 0, 'sold' => 0],
    'bar' => ['labels' => [], 'data' => []],
    'pie' => ['labels' => [], 'data' => []]
];

// 1. Lấy Thống kê tổng quát (Doanh thu & Tổng sản phẩm đã bán)
// Chỉ tính những đơn hàng đã giao thành công (delivered)
$statQuery = "SELECT SUM(total_price) as revenue, SUM(quantity) as sold 
              FROM orders 
              WHERE status = 'delivered'";
if ($filterDate) {
    $statQuery .= " AND DATE(created_at) = '$filterDate'";
}
$statRes = mysqli_query($conn, $statQuery);
$response['stats'] = mysqli_fetch_assoc($statRes);

// 2. Lấy dữ liệu cho BIỂU ĐỒ CỘT (Doanh thu 7 ngày gần nhất)
$barQuery = "SELECT DATE(created_at) as date, SUM(total_price) as daily_revenue 
             FROM orders 
             WHERE status = 'delivered' 
             GROUP BY DATE(created_at) 
             ORDER BY date DESC LIMIT 7";
$barRes = mysqli_query($conn, $barQuery);
$barLabels = []; $barData = [];
while($r = mysqli_fetch_assoc($barRes)) {
    $barLabels[] = date('d/m', strtotime($r['date']));
    $barData[] = (int)$r['daily_revenue'];
}
$response['bar']['labels'] = array_reverse($barLabels);
$response['bar']['data'] = array_reverse($barData);

// 3. Lấy dữ liệu cho BIỂU ĐỒ TRÒN (Top 5 sản phẩm mua nhiều nhất)
$pieQuery = "SELECT p.product_name, SUM(o.quantity) as total_qty 
             FROM orders o 
             JOIN products p ON o.product_id = p.id 
             WHERE o.status = 'delivered' 
             GROUP BY o.product_id 
             ORDER BY total_qty DESC LIMIT 5";
$pieRes = mysqli_query($conn, $pieQuery);
while($r = mysqli_fetch_assoc($pieRes)) {
    $response['pie']['labels'][] = $r['product_name'];
    $response['pie']['data'][] = (int)$r['total_qty'];
}

echo json_encode($response);
?>