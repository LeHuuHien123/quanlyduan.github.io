<?php
session_start();
// Kết nối database (thay đổi thông số cho đúng với máy bạn)
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "shop"; // Tên database của bạn

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Kết nối thất bại: " . $conn->connect_error);
}

// XỬ LÝ ĐĂNG KÝ
if (isset($_POST['register'])) {
    $name = mysqli_real_escape_string($conn, $_POST['name']);
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $pass = password_hash($_POST['password'], PASSWORD_DEFAULT); // Mã hóa mật khẩu

    // Kiểm tra email tồn tại chưa
    $checkEmail = "SELECT * FROM users WHERE email='$email'";
    $result = $conn->query($checkEmail);

    if ($result->num_rows > 0) {
        echo "<script>alert('Email này đã được đăng ký!'); window.location.href='../login.html';</script>";
    } else {
        $sql = "INSERT INTO users (fullname, email, password, role) VALUES ('$name', '$email', '$pass', 'user')";
        if ($conn->query($sql) === TRUE) {
            echo "<script>alert('Đăng ký thành công!'); window.location.href='../login.html';</script>";
        } else {
            echo "Lỗi: " . $sql . "<br>" . $conn->error;
        }
    }
}

// XỬ LÝ ĐĂNG NHẬP
if (isset($_POST['login'])) {
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $pass = $_POST['password'];

    $sql = "SELECT * FROM users WHERE email='$email'";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        // Kiểm tra mật khẩu mã hóa
        if (password_verify($pass, $row['password'])) {
            $_SESSION['user_id'] = $row['id'];
            $_SESSION['fullname'] = $row['fullname']; // Đảm bảo dòng này dùng 'fullname'
            $_SESSION['role'] = $row['role'];

            // Phân quyền: Nếu là admin thì vào trang quản trị, user vào trang chủ
            if ($row['role'] == 'admin') {
                header("Location: ../admin.php");
            } else {
                header("Location: ../index.php");
            }
        } else {
            echo "<script>alert('Sai mật khẩu!'); window.location.href='../login.html';</script>";
        }
    } else {
        echo "<script>alert('Email không tồn tại!'); window.location.href='../login.html';</script>";
    }
}

$conn->close();
?>