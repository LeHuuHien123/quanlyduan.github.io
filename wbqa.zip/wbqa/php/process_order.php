<?php
include 'datk.php';
session_start();

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_SESSION['user_id'])) {
    $order_ids = $_POST['order_ids']; // Chuỗi ID dạng "1,2,3"
    $phone = mysqli_real_escape_string($conn, $_POST['phone']);
    $address = mysqli_real_escape_string($conn, $_POST['address']);
    $note = mysqli_real_escape_string($conn, $_POST['note']);
    $payment = $_POST['payment_method'];

    // Cập nhật trạng thái từ 'pending' sang 'waiting_confirm'
    // Lưu ý: Chúng ta cập nhật các cột thông tin giao hàng vào bảng orders
    $sql = "UPDATE orders SET 
            status = 'waiting_confirm', 
            phone = '$phone', 
            address = '$address', 
            note = '$note',
            payment_method = '$payment',
            created_at = NOW() 
            WHERE id IN ($order_ids)";

    if (mysqli_query($conn, $sql)) {
        echo "success";
    } else {
        echo "Lỗi kết nối: " . mysqli_error($conn);
    }
} else {
    echo "Yêu cầu không hợp lệ";
}
?>