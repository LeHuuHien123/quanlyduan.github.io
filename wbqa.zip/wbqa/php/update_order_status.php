<?php
session_start();
include 'datk.php'; 

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['ids']) && isset($_POST['status'])) {
    
    if (!isset($_SESSION['user_id'])) {
        echo json_encode(['success' => false, 'message' => 'Bạn chưa đăng nhập.']);
        exit();
    }

    // 1. Xử lý an toàn chuỗi IDs (Chuyển "1,2,3" thành mảng số nguyên)
    $raw_ids = explode(',', $_POST['ids']);
    $clean_ids_array = array_map('intval', $raw_ids);
    $ids_string = implode(',', $clean_ids_array);

    if (empty($ids_string)) {
        echo json_encode(['success' => false, 'message' => 'Danh sách ID không hợp lệ.']);
        exit();
    }

    $status = mysqli_real_escape_string($conn, $_POST['status']);
    $session_user_id = (int)$_SESSION['user_id'];
    $role = $_SESSION['role'] ?? 'user';

    // 2. Xây dựng câu lệnh SQL dựa trên vai trò
    if ($role === 'admin') {
        // Admin: Cập nhật mọi đơn trong list
        $sql = "UPDATE orders SET status = '$status' WHERE id IN ($ids_string)";
    } else {
        // User: Chỉ hủy đơn của chính mình khi đang chờ xác nhận
        // Đảm bảo user chỉ được chuyển trạng thái sang 'cancelled' (Hủy)
        if ($status !== 'cancelled') {
            echo json_encode(['success' => false, 'message' => 'Bạn không có quyền thực hiện thao tác này.']);
            exit();
        }
        $sql = "UPDATE orders SET status = '$status' 
                WHERE id IN ($ids_string) 
                AND user_id = $session_user_id 
                AND status = 'waiting_confirm'";
    }
    
    if (mysqli_query($conn, $sql)) {
        // Trả về thành công nếu câu lệnh chạy được
        // Kể cả rows_affected = 0 (do trùng trạng thái cũ) thì vẫn tính là thành công về mặt logic
        echo json_encode(['success' => true]);
    } else {
        echo json_encode(['success' => false, 'message' => 'Lỗi hệ thống: ' . mysqli_error($conn)]);
    }
} else {
    echo json_encode(['success' => false, 'message' => 'Yêu cầu không hợp lệ.']);
}
?>