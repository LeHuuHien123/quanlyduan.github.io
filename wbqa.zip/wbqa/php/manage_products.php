<?php
session_start();
include 'datk.php'; 

// Kiểm tra quyền (Chỉ Admin/Staff mới được thao tác)
if (!isset($_SESSION['role']) || ($_SESSION['role'] !== 'admin' && $_SESSION['role'] !== 'staff')) {
    die("Bạn không có quyền!");
}

// Lấy hành động từ POST hoặc GET
$action = $_POST['action'] ?? $_GET['action'] ?? '';

// --- LOGIC XÓA SẢN PHẨM ---
if ($action === 'delete') {
    $id = isset($_POST['id']) ? (int)$_POST['id'] : 0;
    
    if ($id > 0) {
        // 1. Xóa các chi tiết đơn hàng liên quan đến sản phẩm này trước
        mysqli_query($conn, "DELETE FROM orders WHERE product_id = $id");

        // 2. Sau đó mới xóa sản phẩm chính
        $sql = "DELETE FROM products WHERE id = $id";
        
        if (mysqli_query($conn, $sql)) {
            echo "success";
        } else {
            echo "Lỗi SQL: " . mysqli_error($conn);
        }
    } else {
        echo "ID không hợp lệ";
    }
    exit;
}

// --- LOGIC LƯU (THÊM/SỬA) ---
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $id = isset($_POST['id']) ? (int)$_POST['id'] : 0;
    
    $name = mysqli_real_escape_string($conn, $_POST['product_name']);
    $category = mysqli_real_escape_string($conn, $_POST['category']);
    $size_raw = mysqli_real_escape_string($conn, $_POST['size']); 
    $price = (int)$_POST['price'];
    $image = mysqli_real_escape_string($conn, $_POST['image']);
    $description = mysqli_real_escape_string($conn, $_POST['description']);

    // Tính toán tồn kho từ chuỗi Size (VD: S:10,M:5 => 15)
    $total_stock = 0;
    $size_standard = str_replace('.', ',', $size_raw); 
    $size_parts = explode(',', $size_standard); 
    
    foreach ($size_parts as $part) {
        $item = explode(':', $part);
        if (count($item) == 2) {
            $total_stock += (int)trim($item[1]); 
        }
    }

    if ($id > 0) {
        // CẬP NHẬT
        $sql = "UPDATE products SET 
                product_name='$name', category='$category', size='$size_standard', 
                price='$price', stock='$total_stock', image='$image', description='$description' 
                WHERE id=$id";
    } else {
        // THÊM MỚI
        $sql = "INSERT INTO products (product_name, category, size, price, stock, image, description) 
                VALUES ('$name', '$category', '$size_standard', '$price', '$total_stock', '$image', '$description')";
    }

    if (mysqli_query($conn, $sql)) {
        echo "success";
    } else {
        echo "Lỗi SQL: " . mysqli_error($conn);
    }
}
?>