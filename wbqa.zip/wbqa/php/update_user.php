<?php
include "datk.php";

$id = intval($_POST['id']);
$name = mysqli_real_escape_string($conn,$_POST['fullname']);
$email = mysqli_real_escape_string($conn,$_POST['email']);
$phone = mysqli_real_escape_string($conn,$_POST['phone']);
$address = mysqli_real_escape_string($conn,$_POST['address']);

$sql = "UPDATE users SET
        fullname='$name',
        email='$email',
        phone='$phone',
        address='$address'
        WHERE id=$id";

if(mysqli_query($conn,$sql)){
    echo "success";
}else{
    echo mysqli_error($conn);
}
?>