<?php
session_start();
$host = 'localhost'; $user = 'root'; $pass = ''; $db = 'golden_feast_db';
$conn = new mysqli($host, $user, $pass, $db);
mysqli_set_charset($conn, "utf8mb4");

$action = $_REQUEST['action'] ?? '';
$user_id = isset($_REQUEST['user_id']) ? intval($_REQUEST['user_id']) : 0;

if ($action == 'get_waiting_list') {
    // Thêm subquery để lấy type của tin nhắn cuối cùng
    $sql = "SELECT user_id, username, is_accepted, COUNT(id) as total_msgs,
            (SELECT type FROM chat_messages WHERE user_id = m.user_id ORDER BY id DESC LIMIT 1) as last_sender
            FROM chat_messages m 
            GROUP BY user_id 
            ORDER BY id DESC";

    $res = $conn->query($sql);
    if ($res && $res->num_rows > 0) {
        while($row = $res->fetch_assoc()) {
            $name = htmlspecialchars($row['username']);
            $u_id = $row['user_id'];
            $total = $row['total_msgs'];
            
            // Xác định class màu dựa trên người nhắn cuối cùng
            $status_class = ($row['last_sender'] == 'user') ? 'waiting' : 'replied';
            $is_waiting = ($row['last_sender'] == 'user') ? 1 : 0;
            
            $status_btn = (isset($row['is_accepted']) && $row['is_accepted'] == 0) 
                ? "<button class='btn-approve' onclick='event.stopPropagation(); acceptChat($u_id)'>DUYỆT NGAY</button>" 
                : "<span class='status-ready'>● Đang kết nối</span>";

            // Thêm class màu và data-msgs vào div
            echo "<div class='user-item $status_class' data-msgs='$is_waiting' id='user-item-$u_id' onclick='selectUser($u_id, \"$name\")'>";
            echo "  <div class='user-info'>";
            echo "    <span class='user-name'>👤 $name</span>";
            echo "    $status_btn";
            echo "  </div>";
            echo "</div>";
        }
    } else {
        echo "<div style='color:#666; padding:10px; font-size:11px;'>Chưa có khách nhắn tin...</div>";
    }
}

// --- 2. CHẤP NHẬN KẾT NỐI (Duyệt Chat) ---
if ($action == 'accept' && $user_id > 0) {
    // Cập nhật trạng thái is_accepted = 1 cho tất cả tin nhắn của khách này
    $sql = "UPDATE chat_messages SET is_accepted = 1 WHERE user_id = '$user_id'";
    
    if ($conn->query($sql) === TRUE) {
        echo "OK"; // Trả về để Javascript nhận biết và load khung chat
    } else {
        echo "ERROR";
    }
}

// --- 3. HỦY ĐOẠN CHÁT (Xóa lịch sử) ---
if ($action == 'end_chat' && $user_id > 0) {
    // Xóa toàn bộ tin nhắn liên quan đến user_id này
    $sql = "DELETE FROM chat_messages WHERE user_id = '$user_id'";
    
    if ($conn->query($sql) === TRUE) {
        echo "SUCCESS"; // Trả về để Javascript reset khung chat
    } else {
        echo "ERROR: " . $conn->error;
    }
}

$conn->close();
?>