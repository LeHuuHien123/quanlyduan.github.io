/**
 * TOÀN BỘ CODE ADMIN.JS - ĐÃ TỐI ƯU VÀ KHÔNG LẶP
 */

// Biến biểu đồ toàn cục để tránh lỗi ghi đè
let myBarChart, myPieChart;

document.addEventListener('DOMContentLoaded', () => {
    // 1. Khởi tạo dữ liệu Dashboard
    loadDashboardData();

    // 2. Xử lý Form Sản phẩm (Thêm & Sửa)
    const productForm = document.getElementById('productForm');
    if (productForm) {
        productForm.onsubmit = function(e) {
            e.preventDefault();
            const fd = new FormData(this);
            const id = document.getElementById('prodId').value;
            
            fd.append('action', 'save'); 

            fetch('php/manage_products.php', { method: 'POST', body: fd })
            .then(res => res.text())
            .then(data => {
                if (data.trim() === 'success') {
                    alert("✅ Đã lưu sản phẩm!");
                    location.reload(); 
                } else {
                    alert("Lỗi: " + data);
                }
            });
        };
    }

    // 3. Xử lý Form Người dùng (Thêm & Sửa)
    // Đảm bảo đoạn này nằm trong document.addEventListener('DOMContentLoaded', ...)
const userForm = document.getElementById('userForm');
    if (userForm) {
        userForm.onsubmit = function(e) {
            e.preventDefault();
            const fd = new FormData(this);
            fd.append('action', 'save'); 

            fetch('./php/manager_users.php', { method: 'POST', body: fd })
            .then(res => res.text())
            .then(data => {
                console.log("Server response:", data);
                if (data.trim() === 'success') {
                    alert("✅ Thao tác thành công!");
                    location.reload(); 
                } else {
                    alert("❌ Lỗi: " + data);
                }
            })
            .catch(err => alert("❌ Không tìm thấy file php/manage_users.php (Lỗi 404)"));
        };
    }
});

// --- PHẦN 1: THỐNG KÊ & BIỂU ĐỒ (DASHBOARD) ---

async function loadDashboardData(selectedDate = '') {
    try {
        const url = selectedDate ? `php/get_stats.php?date=${selectedDate}` : 'php/get_stats.php';
        const response = await fetch(url);
        const data = await response.json();

        // Cập nhật số liệu Header
        const revEl = document.getElementById('stat-revenue');
        const soldEl = document.getElementById('stat-sold');
        if(revEl) revEl.innerText = new Intl.NumberFormat('vi-VN').format(data.stats.revenue || 0) + 'đ';
        if(soldEl) soldEl.innerText = data.stats.sold || 0;

        renderCharts(data.bar, data.pie);
    } catch (error) {
        console.error("Lỗi lấy dữ liệu dashboard:", error);
    }
}

function renderCharts(barData, pieData) {
    const ctxBar = document.getElementById('barChart')?.getContext('2d');
    const ctxPie = document.getElementById('pieChart')?.getContext('2d');
    if (!ctxBar || !ctxPie) return;

    if (myBarChart) myBarChart.destroy();
    if (myPieChart) myPieChart.destroy();

    myBarChart = new Chart(ctxBar, {
        type: 'bar',
        data: {
            labels: barData.labels,
            datasets: [{
                label: 'Doanh thu (VNĐ)',
                data: barData.data,
                backgroundColor: '#e67e22',
                borderRadius: 8
            }]
        }
    });

    myPieChart = new Chart(ctxPie, {
        type: 'doughnut',
        data: {
            labels: pieData.labels,
            datasets: [{
                data: pieData.data,
                backgroundColor: ['#e67e22', '#3498db', '#2ecc71', '#f1c40f', '#9b59b6']
            }]
        },
        options: { plugins: { legend: { position: 'bottom' } } }
    });
}

function updateCharts() {
    const date = document.getElementById('filterDate').value;
    loadDashboardData(date);
}

// --- PHẦN 2: QUẢN LÝ SẢN PHẨM ---

function openProductModal() {
    const form = document.getElementById('productForm');
    form.reset();
    document.getElementById('prodId').value = "";
    document.getElementById('modalTitle').innerText = "Thêm Sản Phẩm Mới";
    document.getElementById('productModal').style.display = 'block';
}

function editProduct(prod) {
    document.getElementById('modalTitle').innerText = "Chỉnh Sửa Sản Phẩm";
    document.getElementById('prodId').value = prod.id;
    document.getElementById('prodName').value = prod.product_name;
    document.getElementById('prodCategory').value = prod.category;
    document.getElementById('prodPrice').value = prod.price;
    document.getElementById('prodSize').value = prod.size;
    document.getElementById('prodImg').value = prod.image;
    document.getElementById('prodDesc').value = prod.description;
    document.getElementById('productModal').style.display = 'block';
}

function deleteProduct(id) {
    if (!confirm("⚠️ Xác nhận xóa sản phẩm này?")) return;
    const fd = new FormData();
    fd.append('id', id);
    fd.append('action', 'delete');

    fetch('php/manage_products.php', { method: 'POST', body: fd })
    .then(res => res.text())
    .then(data => {
        if (data.trim() === 'success') {
            const row = document.querySelector(`tr[data-id="${id}"]`);
            if (row) row.remove();
            alert("Đã xóa sản phẩm!");
        } else { alert("Lỗi: " + data); }
    });
}

// --- PHẦN 3: QUẢN LÝ NGƯỜI DÙNG ---

function openUserModal() {
    const form = document.getElementById('userForm');
    form.reset();
    document.getElementById('userId').value = "";
    document.getElementById('userPass').required = true; 
    document.getElementById('userPass').placeholder = "Nhập mật khẩu mới";
    document.getElementById('userModal').style.display = 'block';
}

// Hàm mở Modal chỉnh sửa
function editUser(user) {
    document.getElementById('userId').value = user.id;
    document.getElementById('userName').value = user.fullname || '';
    document.getElementById('userEmail').value = user.email;
    
    const roleSelect = document.getElementById('userRole');
    if (roleSelect) roleSelect.value = user.role;

    const passInput = document.getElementById('userPass');
    if (passInput) {
        passInput.value = ''; 
        passInput.required = false; 
        passInput.placeholder = "Bỏ trống nếu không đổi";
    }
    document.getElementById('userModal').style.display = 'block';
}

// Hàm xóa người dùng
function deleteUser(id) {
    if (!confirm("⚠️ Bạn có chắc chắn muốn xóa vĩnh viễn?")) return;

    const fd = new FormData();
    fd.append('id', id);
    fd.append('action', 'delete');

    fetch('./php/manager_users.php', { method: 'POST', body: fd })
    .then(res => res.text())
    .then(data => {
        if (data.trim() === 'success') {
            const row = document.querySelector(`tr[data-user-id='${id}']`);
            if (row) row.remove();
            alert("✅ Đã xóa!");
        } else {
            alert("❌ Lỗi: " + data);
        }
    })
    .catch(err => alert("❌ Lỗi kết nối server (404 Not Found)"));
}
// --- PHẦN 4: QUẢN LÝ ĐƠN HÀNG ---

function updateGroupStatus(listIds, newStatus, selectElement) {
    if(!confirm('Xác nhận thay đổi trạng thái?')) return;
    fetch('php/update_order_status.php', {  
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: `ids=${listIds}&status=${newStatus}`
    })
    .then(res => res.json())
    .then(data => {
        if(data.success) {
            alert('Cập nhật thành công!');
            selectElement.style.background = (newStatus === 'delivered') ? '#d4edda' : '#fff';
        } else { alert('Lỗi: ' + data.message); }
    });
}

function deleteOrderGroup(listIds) {
    if (!confirm('⚠️ Xác nhận xóa vĩnh viễn nhóm đơn hàng này?')) return;
    const params = new URLSearchParams();
    params.append('ids', listIds);

    fetch('php/delete_order.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: params.toString()
    })
    .then(res => res.json())
    .then(data => {
        if (data.success) {
            alert('Đã xóa thành công!');
            location.reload(); 
        } else { alert('Lỗi: ' + data.message); }
    })
    .catch(err => alert('Lỗi kết nối: ' + err.message));
}

// --- ĐÓNG MODALS ---
function closeProductModal() { document.getElementById('productModal').style.display = 'none'; }
function closeUserModal() { document.getElementById('userModal').style.display = 'none'; }