document.addEventListener('DOMContentLoaded', () => {
    const container = document.getElementById('serviceContainer');
    const searchInput = document.getElementById('searchService');
    const typeSelect = document.getElementById('filterServiceType');
    const priceRange = document.getElementById('filterServicePrice');
    const priceDisplay = document.getElementById('priceValue');
    const resetBtn = document.getElementById('resetServiceFilter');

    function renderServices(data) {
        if (!container) return;
        
        container.innerHTML = data.map(s => `
            <div class="svc-item">
                <div class="svc-img">
                    <img src="${s.image}" alt="${s.service_name}">
                </div>
                <div class="svc-info">
                    <span class="tag">${s.service_type}</span>
                    <h2>${s.service_name}</h2>
                    <p>${s.description || 'Nâng tầm bữa tiệc của bạn với dịch vụ chuyên nghiệp, tận tâm từ đội ngũ Golden Feast.'}</p>
                    <span class="price">${new Intl.NumberFormat('vi-VN').format(s.price)} đ</span>
                    <a href="booking.php" class="svc-btn">Đặt dịch vụ này</a>
                </div>
            </div>
        `).join('');

        // Gọi hiệu ứng hiện dần
        handleScroll();
    }

    function handleScroll() {
        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    entry.target.classList.add('visible');
                }
            });
        }, { threshold: 0.2 });

        document.querySelectorAll('.svc-item').forEach(item => observer.observe(item));
    }

    function filterData() {
        const term = searchInput.value.toLowerCase();
        const type = typeSelect.value;
        const maxPrice = priceRange.value * 1000000;

        const filtered = allServices.filter(s => {
            return (s.service_name.toLowerCase().includes(term)) &&
                   (type === 'all' || s.service_type === type) &&
                   (parseFloat(s.price) <= maxPrice);
        });
        renderServices(filtered);
    }

    // Sự kiện
    searchInput.addEventListener('input', filterData);
    typeSelect.addEventListener('change', filterData);
    priceRange.addEventListener('input', (e) => {
        priceDisplay.innerText = e.target.value;
        filterData();
    });
    resetBtn.onclick = () => {
        searchInput.value = '';
        typeSelect.value = 'all';
        priceRange.value = 20;
        priceDisplay.innerText = 20;
        renderServices(allServices);
    };

    renderServices(allServices);
});