    <?php
    session_start();
    include 'php/datk.php';

    if (!isset($_SESSION['user_id'])) {
        header("Location: login.html");
        exit();
    }
    $user_id = $_SESSION['user_id'];

    /// Truy vấn lấy thông tin người dùng
    $sql_user = "SELECT phone, address FROM users WHERE id = $user_id";
    $res_user = mysqli_query($conn, $sql_user);
    $conn = mysqli_connect("localhost", "root", "", "shop");
    // Khởi tạo mặc định
    $user_phone = '';
    $user_address = '';

    if ($res_user && mysqli_num_rows($res_user) > 0) {
        // CHỈ GỌI MỘT LẦN DUY NHẤT Ở ĐÂY
        $user_info = mysqli_fetch_assoc($res_user);
        $user_phone = $user_info['phone'] ?? '';
        $user_address = $user_info['address'] ?? '';
}

    // 1. ĐỊNH NGHĨA TRẠNG THÁI (Sửa lỗi "Không xác định")
    $status_map = [
    // Chuyển màu Chờ xử lý thành màu đỏ (#e74c3c)
    'waiting_confirm' => ['label' => '⏳ Chờ xử lý', 'color' => '#e74c3c'], 
    'confirmed'       => ['label' => '✅ Đã xác nhận', 'color' => '#27ae60'],
    'shipped_to_hub'  => ['label' => '📦 Đã gửi bưu cục', 'color' => '#3498db'],
    'in_transit'      => ['label' => '🚚 Đang giao hàng', 'color' => '#9b59b6'],
    'delivered'       => ['label' => '🏁 Hoàn tất', 'color' => '#2c3e50'],
    'cancelled'       => ['label' => '❌ Đã hủy', 'color' => '#7f8c8d']
];
    ?>
    <!DOCTYPE html>
    <html lang="vi">
    <head>
        <meta charset="UTF-8">
        <title>Giỏ Hàng & Lịch Sử - Fashion Shop</title>
        <link rel="stylesheet" href="css/dungchung.css">
        <link rel="stylesheet" href="css/navbar.css">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
       <style>
    /* --- TỔNG THỂ --- */
    body { background-color: #fdfaf9; } /* Nền kem cực nhạt */
    .cart-container { padding: 140px 8% 50px; min-height: 80vh; max-width: 1300px; margin: 0 auto; }

    /* --- TABS (CHUYỂN ĐỔI) - PHONG CÁCH LUXURY --- */
    .tab-btn-container { 
        display: flex; 
        gap: 20px; 
        margin-bottom: 30px; 
        border-bottom: 1px solid #efebe9; 
    }
    .tab-btn { 
        padding: 15px 10px; 
        cursor: pointer; 
        font-weight: 600; 
        color: #a1887f; /* Nâu nhạt */
        text-transform: uppercase;
        letter-spacing: 1.5px;
        font-size: 13px;
        transition: 0.3s; 
        border-bottom: 3px solid transparent;
        background: transparent;
        border-top: none;
        border-left: none;
        border-right: none;
    }
    .tab-btn.active { 
        color: #5d4037; /* Nâu đậm */
        border-bottom-color: #8d6e63; /* Màu Nâu chủ đạo */
    }

    /* --- BẢNG GIỎ HÀNG (TRẮNG NÂU THANH LỊCH) --- */
    .cart-table { 
        width: 100%; 
        border-collapse: separate; 
        border-spacing: 0 12px; 
        background: transparent;
    }
    .cart-table th { 
        background: #f5f0ee; /* Nền header màu kem đậm */
        color: #5d4037; 
        padding: 18px; 
        text-transform: uppercase;
        font-size: 12px;
        letter-spacing: 1.5px;
        font-weight: 700;
        border: none;
        border-radius: 4px;
    }
    .cart-table tr.cart-row, .cart-table tbody tr { 
        background: #fff; 
        box-shadow: 0 4px 15px rgba(141, 110, 99, 0.08); /* Đổ bóng màu nâu cực nhẹ */
        transition: 0.3s;
    }
    .cart-table tr.cart-row:hover {
        transform: translateY(-3px);
        box-shadow: 0 8px 25px rgba(141, 110, 99, 0.12);
    }
    .cart-table td { 
        padding: 20px; 
        vertical-align: middle;
        border: none;
        color: #4e342e;
    }
    .cart-table tr td:first-child { border-radius: 12px 0 0 12px; }
    .cart-table tr td:last-child { border-radius: 0 12px 12px 0; }

    /* --- NÚT TĂNG GIẢM SỐ LƯỢNG --- */
    .qty-btn {
        width: 30px;
        height: 30px;
        border: 1px solid #d7ccc8;
        border-radius: 4px; /* Chuyển sang bo nhẹ thay vì tròn xoe */
        background: #fff;
        color: #5d4037;
        cursor: pointer;
        font-weight: bold;
        transition: 0.3s;
    }
    .qty-btn:hover {
        background: #8d6e63;
        color: #fff;
        border-color: #8d6e63;
    }

    /* --- BADGE TRẠNG THÁI --- */
    .status-badge { 
        padding: 6px 16px; 
        border-radius: 4px; 
        font-size: 10px; 
        color: #fff; 
        font-weight: 600; 
        text-transform: uppercase;
        letter-spacing: 0.5px;
    }
    /* Các màu trạng thái theo tông Nâu/Đất */
    .status-waiting_confirm { background: #a1887f; }
    .status-shipping { background: #8d6e63; }
    .status-delivered { background: #5d4037; }

    /* --- MODAL THANH TOÁN --- */
    .modal { 
        display: none;
        position: fixed; 
        z-index: 9999; 
        top: 0; left: 0; width: 100%; height: 100%; 
        background: rgba(78, 52, 46, 0.6); /* Overlay màu nâu mờ */
        backdrop-filter: blur(5px);
    }
    #modalInner {
        border-radius: 12px !important;
        box-shadow: 0 25px 60px rgba(78, 52, 46, 0.2) !important;
        border-top: 6px solid #8d6e63;
        background: #fff;
    }
    
    /* --- NÚT BẤM CHUNG --- */
    .btn-main {
        background: #8d6e63;
        color: #fff;
        border: none;
        padding: 12px 25px;
        border-radius: 4px;
        font-weight: 600;
        text-transform: uppercase;
        letter-spacing: 1px;
        font-size: 13px;
        transition: 0.3s;
        cursor: pointer;
    }
    .btn-main:hover {
        background: #5d4037;
        transform: translateY(-2px);
        box-shadow: 0 5px 15px rgba(93, 64, 55, 0.2);
    }

    /* --- TAB CONTROL --- */
    .tab-content { display: none; }
    .tab-content.active { display: block; animation: fadeIn 0.5s ease; }
    .detail-row { display: none; background: #fdfaf9; }

    @keyframes fadeIn {
        from { opacity: 0; } to { opacity: 1; }
    }
    /* Chỉnh kích thước ảnh sản phẩm trong bảng giỏ hàng */
.cart-img {
    width: 70px;          /* Độ rộng nhỏ gọn */
    height: 90px;         /* Chiều cao lớn hơn chút để giữ form quần áo */
    object-fit: cover;    /* Giữ ảnh không bị méo */
    border-radius: 8px;   /* Bo góc đồng bộ với style chung */
    border: 1px solid #efebe9;
    box-shadow: 0 2px 8px rgba(141, 110, 99, 0.1);
}

/* Căn chỉnh lại cột sản phẩm để ảnh và chữ đẹp hơn */
.cart-table td:nth-child(2) {
    display: flex;
    align-items: center;
    gap: 15px;
    min-width: 250px; /* Đảm bảo tên sản phẩm không bị đẩy xuống dòng quá sớm */
}

.cart-table td strong {
    font-size: 14px;
    color: #5d4037;
}
</style>
    </head>
    <body>
        <nav class="navbar">
        <div class="navbar-container">
            <a href="index.php" class="logo">
                <img src="img/logo/1.png" alt="Fashion Shop" style="height: 50px; width: auto; object-fit: contain;">
            </a>
            <ul class="nav-links">
                <li><a href="index.php">Trang Chủ</a></li>
                <li><a href="shop.php">Cửa Hàng</a></li>
                <li><a href="index.php#new-arrivals">Hàng Mới</a></li>
                <li><a href="evaluate.php">Đánh giá</a></li>
                <li><a href="about.html">Về Chúng Tôi</a></li>
            </ul>

            <div class="nav-btns">
                <?php if(isset($_SESSION['user_id'])): ?>
                    <div class="user-dropdown">
                        <div class="dropdown-toggle">
                            <small class="welcome-text">Chào,</small>
                            <span class="user-name-display"><?php echo $_SESSION['fullname']; ?></span>
                            <i class="fa-solid fa-chevron-down" style="font-size: 10px; margin-left: 5px;"></i>
                        </div>
                        <ul class="dropdown-menu">
                            <li><a href="profile.php"><i class="fa-solid fa-user"></i> Hồ sơ cá nhân</a></li>
                            <li><a href="cart.php"><i class="fa-solid fa-cart-shopping"></i> Giỏ hàng</a></li>
                            <?php if($_SESSION['role'] == 'admin'): ?>
                                <li><a href="admin.php"><i class="fa-solid fa-user-shield"></i> Trang quản trị</a></li>
                            <?php endif; ?>
                            <hr style="border: 0.5px solid #eee; margin: 5px 0;">
                            <li><a href="php/logout.php" class="logout-link"><i class="fa-solid fa-right-from-bracket"></i> Đăng xuất</a></li>
                        </ul>
                    </div>
                <?php else: ?>
                    <a href="login.html" class="btn-login">Đăng nhập</a>
                <?php endif; ?>
                <a href="shop.php" class="btn-main"><i class="fa-solid fa-cart-shopping"></i> Mua Ngay</a>
            </div>
        </div>
    </nav>

        <div class="cart-container">
    <div class="tab-btn-container">
        <div class="tab-btn active" onclick="switchTab('cart-tab', this)">Giỏ Hàng</div>
        <div class="tab-btn" onclick="switchTab('history-tab', this)">Lịch Sử Đơn Hàng</div>
    </div>

    <div id="cart-tab" class="tab-content active">
        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 15px; background: #f9f9f9; padding: 15px; border-radius: 8px;">
            <div>
                <input type="checkbox" id="selectAllTop" onclick="toggleAll(this)" style="margin-right: 10px;">
                <label for="selectAllTop">Chọn tất cả</label>
            </div>
            <div style="display: flex; gap: 10px;">
                <button class="btn-secondary" onclick="removeSelectedItems()" style="background:#f39c12; color:white; padding:8px 15px; border:none; border-radius:5px; cursor:pointer;">
                    <i class="fa-solid fa-eraser"></i> Xóa mục đã chọn
                </button>
                <button class="btn-danger" onclick="removeAllCart()" style="background:#e74c3c; color:white; padding:8px 15px; border:none; border-radius:5px; cursor:pointer;">
                    <i class="fa-solid fa-trash-can"></i> Xóa tất cả
                </button>
            </div>
        </div>

        <table class="cart-table">
            <thead>
                <tr>
                    <th width="50">#</th>
                    <th>Sản phẩm</th>
                    <th>Giá</th>
                    <th>Số lượng</th>
                    <th>Thành tiền</th>
                    <th>Thao tác</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $sql_cart = "SELECT o.*, p.product_name, p.image, p.price FROM orders o 
                             JOIN products p ON o.product_id = p.id 
                             WHERE o.user_id = $user_id AND o.status = 'pending' ORDER BY o.id DESC";
                $res_cart = mysqli_query($conn, $sql_cart);
                if(mysqli_num_rows($res_cart) > 0) {
                    while($row = mysqli_fetch_assoc($res_cart)){
                        $img = explode(',', $row['image'])[0];
                ?>
                    <tr class="cart-row" data-id="<?= $row['id'] ?>">
                        <td><input type="checkbox" class="item-checkbox" data-price="<?= $row['total_price'] ?>" onclick="calculateTotal()"></td>
                        <td style="display:flex; align-items:center; gap:15px;">
                            <img src="<?= $img ?>" class="cart-img">
                            <strong><?= $row['product_name'] ?></strong>
                        </td>
                        <td><?= number_format($row['price']) ?>đ</td>
                        <td>
                            <button class="qty-btn" onclick="updateQty(<?= $row['id'] ?>, -1)">-</button>
                            <span id="qty-<?= $row['id'] ?>" style="margin: 0 10px; font-weight: bold;"><?= $row['quantity'] ?></span>
                            <button class="qty-btn" onclick="updateQty(<?= $row['id'] ?>, 1)">+</button>
                        </td>
                        <td><strong style="color: #e67e22;"><?= number_format($row['total_price']) ?>đ</strong></td>
                        <td>
                            <button onclick="removeCartItem(<?= $row['id'] ?>)" style="background:none; border:none; color:#e74c3c; cursor:pointer;">
                                <i class="fa-solid fa-trash"></i>
                            </button>
                        </td>
                    </tr>
                <?php } } else { ?>
                    <tr><td colspan="6" style="text-align:center; padding:50px;">Giỏ hàng trống. <a href="shop.php" style="color:#e67e22;">Mua sắm ngay!</a></td></tr>
                <?php } ?>
            </tbody>
        </table>

        <div style="text-align:right; margin-top:20px; padding: 20px; background: #fff; border-radius: 10px; box-shadow: 0 5px 15px rgba(0,0,0,0.05);">
            <h3>Tổng cộng: <span id="grandTotal" style="color:#e67e22; font-size: 1.5rem;">0đ</span></h3>
            <button class="btn-main" onclick="processCheckout()" style="padding: 12px 40px; margin-top:10px;">TIẾN HÀNH THANH TOÁN</button>
        </div>
    </div>

    <div id="history-tab" class="tab-content">
    <table class="cart-table">
        <thead>
            <tr>
                <th>Mã đơn</th>
                <th>Ngày đặt</th>
                <th>Tổng tiền</th>
                <th>Trạng thái</th>
                <th>Thao tác</th>
            </tr>
        </thead>
        <tbody>
        <?php
        $sql_history_grouped = "
            SELECT o.phone, o.address, o.status, o.note, 
            SUM(o.total_price) as grand_total, 
            GROUP_CONCAT(o.id) as list_ids, 
            MAX(o.id) as group_display_id, 
            MAX(o.created_at) as order_date 
            FROM orders o 
            WHERE o.user_id = $user_id AND o.status != 'pending' 
            GROUP BY o.phone, o.address, o.status, o.note, o.created_at 
            ORDER BY group_display_id DESC";

        $res_history = mysqli_query($conn, $sql_history_grouped);

        if(mysqli_num_rows($res_history) > 0) {
            while($h = mysqli_fetch_assoc($res_history)) {
                // SỬA LỖI TẠI ĐÂY: Gán giá trị cho $group_id
                $group_id = $h['group_display_id'];
                
                // 1. Làm sạch dữ liệu trạng thái
                $current_status = strtolower(trim($h['status'])); 
    
                // Nếu không khớp key nào thì ép về màu đỏ của 'waiting_confirm' cho an toàn
                $st = $status_map[$current_status] ?? ['label' => '⏳ Đang xử lý', 'color' => '#e74c3c'];

                // Điều kiện để hiện nút Hủy màu đỏ: Chờ xác nhận HOẶC Đã xác nhận
                $can_cancel = ($current_status == 'waiting_confirm' || $current_status == 'confirmed' || $current_status == '');
        ?>
            <tr style="background:#fdfdfd">
                <td>
                    <?php 
                    // Tạo mã đơn: DH + NgàyThángNăm + GiờPhút + ID
                    $order_code = "DH-" . date("dmy-Hi", strtotime($h['order_date'])) . "-" . $group_id;
                    echo "<b>" . $order_code . "</b>";
                    ?>
                </td>
                <td><?= date("d/m/Y H:i", strtotime($h['order_date'])) ?></td>
                <td style="color:#e67e22; font-weight:bold"><?= number_format($h['grand_total']) ?>đ</td>
                <td>
                    <span class="status-badge" style="background:<?= $st['color'] ?>; padding: 4px 10px; border-radius: 20px; color: #fff; font-size: 11px;">
                        <?= $st['label'] ?>
                    </span>
                </td>
                <td style="display: flex; gap: 10px; align-items: center;">
                    <button onclick="toggleOrderDetails(<?= $group_id ?>)" style="background:none; border:none; cursor:pointer; color:#3498db; font-weight: 600;">
                        Xem <i class="fa-solid fa-chevron-down" id="icon-<?= $group_id ?>"></i>
                    </button>

                    <?php if ($can_cancel): ?>
                        <button onclick="handleCancelOrder('<?= $h['list_ids'] ?>', this)" 
                                style="background:#e74c3c; color:white; border:none; padding:6px 15px; border-radius:4px; cursor:pointer; font-size:12px; font-weight:bold;">
                            <i class="fa-solid fa-trash-can"></i> Hủy đơn
                        </button>
                    <?php else: ?>
                        <button disabled style="background:#dcdde1; color:#7f8c8d; border:none; padding:6px 15px; border-radius:4px; cursor:not-allowed; font-size:12px; font-weight:bold;">
                            <i class="fa-solid fa-ban"></i> Hủy
                        </button>
                    <?php endif; ?>
                </td>
            </tr>

            <tr id="details-<?= $group_id ?>" class="detail-row" style="display: none;">
                <td colspan="5">
                    <div class="detail-box" style="padding: 15px; background: #f9f9f9; border-left: 3px solid #e67e22; margin: 5px;">
                        <p style="font-size:13px; margin-bottom:10px">
                            <b>Địa chỉ:</b> <?= htmlspecialchars($h['address']) ?> | 
                            <b>SĐT:</b> <?= htmlspecialchars($h['phone']) ?> |
                            <b>Ghi chú:</b> <?= htmlspecialchars($h['note'] ?: 'Không có') ?>
                        </p>
                        <table style="width:100%; font-size:14px; border-top: 1px solid #eee;">
                            <?php
                            $sub_ids = $h['list_ids'];
                            $sub_sql = "SELECT p.product_name, o.quantity, o.total_price 
                                        FROM orders o 
                                        JOIN products p ON o.product_id = p.id 
                                        WHERE o.id IN ($sub_ids)";
                            $sub_res = mysqli_query($conn, $sub_sql);
                            while($item = mysqli_fetch_assoc($sub_res)) {
                                echo "<tr>
                                        <td style='padding:8px 0'>• {$item['product_name']}</td>
                                        <td>x{$item['quantity']}</td>
                                        <td style='text-align:right'>".number_format($item['total_price'])."đ</td>
                                      </tr>";
                            }
                            ?>
                        </table>
                    </div>
                </td>
            </tr>
        <?php
            }
        } else {
            echo "<tr><td colspan='5' style='text-align:center; padding:40px'>Chưa có đơn hàng nào trong lịch sử</td></tr>";
        }
        ?>
        </tbody>
    </table>
</div>

<div id="checkoutModal" class="modal">
    <div id="modalInner" style="background:white; width:450px; margin:50px auto; padding:25px; border-radius:10px; position:relative;">
        <h3 style="border-bottom: 1px solid #eee; padding-bottom: 10px;">📦 Thông Tin Giao Hàng</h3>
        <form id="finalCheckoutForm">
            <input type="text" id="finalPhone" placeholder="Số điện thoại" value="<?= htmlspecialchars($user_phone) ?>" required style="width:100%; margin:15px 0 10px; padding:12px; border:1px solid #ddd; border-radius:5px;">
            <textarea id="finalAddress" placeholder="Địa chỉ chi tiết" required style="width:100%; margin:10px 0; padding:12px; border:1px solid #ddd; border-radius:5px; height:80px;"><?= htmlspecialchars($user_address) ?></textarea>
            
            <label style="font-weight: bold; display: block; margin: 10px 0 5px;">Phương thức thanh toán:</label>
            <div style="display: flex;gap: 15px;background: #f9f9f9;padding: 10px;border-radius: 5px;margin-bottom:10px;align-content: stretch;flex-wrap: nowrap;flex-direction: column;">
                <label style="cursor:pointer;"><input type="radio" name="payment_method" value="cod" checked> Đưa tiền khi nhận hàng</label>
                <label style="cursor:pointer;"><input type="radio" name="payment_method" value="banking"> Chuyển khoản</label>
            </div>

            <textarea id="finalNote" placeholder="Ghi chú thêm..." style="width:100%; margin:10px 0; padding:10px; border:1px solid #ddd; border-radius:5px;"></textarea>
            
            <button type="submit" class="btn-main" style="width:100%; padding:12px; background:#e67e22; color:white; border:none; border-radius:5px; font-weight:bold; cursor:pointer;">XÁC NHẬN ĐẶT HÀNG</button>
            <button type="button" onclick="closeCheckoutModal()" style="width:100%; margin-top:10px; background:none; border:none; color:#888; cursor:pointer;">Quay lại</button>
        </form>
    </div>
</div>

<script>
function switchTab(tabId, element) {
    // 1. Ẩn tất cả nội dung tab
    const contents = document.querySelectorAll('.tab-content');
    contents.forEach(content => content.classList.remove('active'));

    // 2. Gỡ bỏ trạng thái active ở các nút bấm
    const buttons = document.querySelectorAll('.tab-btn');
    buttons.forEach(btn => btn.classList.remove('active'));

    // 3. Hiển thị tab được chọn
    document.getElementById(tabId).classList.add('active');

    // 4. Thêm trạng thái active cho nút vừa bấm
    element.classList.add('active');
}

function toggleOrderDetails(id) {
    const el = document.getElementById('details-' + id);
    const icon = document.getElementById('icon-' + id);
    
    if (el.style.display === 'table-row') {
        el.style.display = 'none';
        icon.classList.replace('fa-chevron-up', 'fa-chevron-down');
    } else {
        el.style.display = 'table-row';
        icon.classList.replace('fa-chevron-down', 'fa-chevron-up');
    }
}

// Hàm đóng mở Modal thanh toán
function processCheckout() {
    document.getElementById('checkoutModal').style.display = 'block';
}

function closeCheckoutModal() {
    document.getElementById('checkoutModal').style.display = 'none';
}

// Đóng modal khi click ra ngoài vùng modalInner
window.onclick = function(event) {
    let modal = document.getElementById('checkoutModal');
    if (event.target == modal) {
        modal.style.display = "none";
    }
}
document.getElementById('finalCheckoutForm').onsubmit = function(e) {
    e.preventDefault();

    // Lấy thời gian hiện tại để tạo mã
    const now = new Date();
    const dateStr = now.getDate().toString().padStart(2, '0') + 
                  (now.getMonth()+1).toString().padStart(2, '0') + 
                  now.getFullYear().toString().slice(-2);
    const timeStr = now.getHours().toString().padStart(2, '0') + 
                    now.getMinutes().toString().padStart(2, '0');
    
    // Tạo mã đơn theo định dạng: DH-NgàyThángNăm-GiờPhút
    const fullOrderCode = `DH-${dateStr}-${timeStr}`;                    

    // 1. Lấy danh sách các ID đơn hàng đang được chọn (checkbox)
    const selectedCheckboxes = document.querySelectorAll('.item-checkbox:checked');
    if (selectedCheckboxes.length === 0) {
        alert("Vui lòng chọn ít nhất một sản phẩm để thanh toán!");
        return;
    }

    const orderIds = Array.from(selectedCheckboxes).map(cb => cb.closest('.cart-row').dataset.id).join(',');
    
    // 2. Thu thập thông tin giao hàng
    const phone = document.getElementById('finalPhone').value;
    const address = document.getElementById('finalAddress').value;
    const payment = document.querySelector('input[name="payment_method"]:checked').value;
    const note = document.getElementById('finalNote').value;
    const totalText = document.getElementById('grandTotal').innerText.replace(/[^0-9]/g, '');

    // 3. Gửi dữ liệu lên Server qua AJAX
    const fd = new FormData();
    fd.append('order_ids', orderIds);
    fd.append('phone', phone);
    fd.append('address', address);
    fd.append('payment_method', payment);
    fd.append('note', note);

    fetch('php/process_order.php', {
        method: 'POST',
        body: fd
    })
    .then(res => res.text())
    .then(data => {
        if (data.trim() === 'success') {
            if (payment === 'banking') {
                // THÔNG TIN NGÂN HÀNG
                const bankId = "VCB"; 
                const accountNo = "1037725848"; 
                const accountName = "LE HUU HIEN"; 
                
                // CẬP NHẬT: addInfo sử dụng fullOrderCode thay vì orderIds
                const qrUrl = `https://img.vietqr.io/image/${bankId}-${accountNo}-compact2.png?amount=${totalText}&addInfo=Thanh toan ${fullOrderCode}&accountName=${accountName}`;

                document.getElementById('modalInner').innerHTML = `
                    <div style="text-align:center;">
                        <h3 style="color:#27ae60;">✅ Đặt hàng thành công!</h3>
                        <p style="margin-bottom: 5px;">Mã đơn hàng: <strong>${fullOrderCode}</strong></p>
                        <p>Vui lòng quét mã QR bên dưới để thanh toán:</p>
                        <img src="${qrUrl}" style="width:100%; max-width:250px; border-radius:10px; margin:15px 0; border: 1px solid #eee;">
                        <p style="font-size:13px; color:#666;">Nội dung CK: <strong>Thanh toan ${fullOrderCode}</strong></p>
                        <button onclick="location.reload()" class="btn-main" style="width:100%; margin-top:15px;">Xong</button>
                    </div>
                `;
            } else {
                alert("✅ Đặt hàng thành công! Đơn hàng của bạn đang được xử lý.");
                location.reload();
            }
        } else {
            alert("Lỗi: " + data);
        }
    });
};

// Hàm bổ trợ để tính tổng tiền khi tích chọn sản phẩm
function calculateTotal() {
    let total = 0;
    const selected = document.querySelectorAll('.item-checkbox:checked');
    selected.forEach(cb => {
        total += parseInt(cb.dataset.price);
    });
    document.getElementById('grandTotal').innerText = new Intl.NumberFormat('vi-VN').format(total) + "đ";
}

function toggleAll(source) {
    const checkboxes = document.querySelectorAll('.item-checkbox');
    checkboxes.forEach(cb => cb.checked = source.checked);
    calculateTotal();
}

function updateQty(orderId, change) {
    const qtyElement = document.getElementById('qty-' + orderId);
    let newQty = parseInt(qtyElement.innerText) + change;

    if (newQty < 1) return; // Không cho giảm xuống 0

    const fd = new FormData();
    fd.append('order_id', orderId);
    fd.append('new_qty', newQty);

    fetch('php/update_cart_qty.php', {
        method: 'POST',
        body: fd
    })
    .then(res => res.json())
    .then(data => {
        if (data.status === 'success') {
            qtyElement.innerText = newQty;
            // Cập nhật lại giá hiển thị trên dòng đó
            const row = document.querySelector(`.cart-row[data-id="${orderId}"]`);
            const priceCell = row.querySelectorAll('td')[4].querySelector('strong');
            priceCell.innerText = new Intl.NumberFormat('vi-VN').format(data.new_total) + "đ";
            
            // Cập nhật thuộc tính data-price của checkbox để tính tổng lại cho đúng
            row.querySelector('.item-checkbox').dataset.price = data.new_total;
            calculateTotal();
        }
    });
}
function cancelOrderGroup(listIds) {
    if (!confirm('Bạn có chắc muốn hủy đơn hàng này?')) return;

    fetch('update_order_status.php', { // Kiểm tra kỹ tên file này
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: 'id=' + listIds + '&status=cancelled'
    })
    .then(response => {
        if (!response.ok) throw new Error('Cảnh báo: File xử lý không tồn tại (Lỗi 404)!');
        return response.text(); // Đọc dạng text trước để tránh lỗi JSON
    })
    .then(data => {
        if (data.trim() === "success") {
            alert('Hủy đơn thành công!');
            location.reload();
        } else {
            alert('Server trả về lỗi: ' + data);
        }
    })
    .catch(error => {
        alert('Lỗi kết nối: ' + error.message);
    });
}
function handleCancelOrder(listIds, buttonElement) {
    if (!confirm('Bạn có chắc chắn muốn hủy đơn hàng này không?')) return;

    // Hiệu ứng chờ
    const originalContent = buttonElement.innerHTML;
    buttonElement.innerHTML = "⏳ Đang xử lý...";
    buttonElement.disabled = true;

    // Gửi yêu cầu cập nhật tới server
    // LƯU Ý: Đảm bảo file update_order_status.php nằm cùng thư mục với file này
    fetch('php/update_order_status.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        // Sử dụng tham số 'ids' để khớp với code PHP bên dưới
        body: `ids=${listIds}&status=cancelled`
    })
    .then(response => {
        if (!response.ok) throw new Error('Không tìm thấy file xử lý (404). Vui lòng kiểm tra lại vị trí file!');
        return response.json();
    })
    .then(data => {
        if (data.success) {
            alert('✅ Đã hủy đơn hàng thành công!');
            location.reload(); 
        } else {
            alert('Lỗi: ' + data.message);
            buttonElement.innerHTML = originalContent;
            buttonElement.disabled = false;
        }
    })
    .catch(error => {
        console.error('Error:', error);
        alert('Có lỗi xảy ra: ' + error.message);
        buttonElement.innerHTML = originalContent;
        buttonElement.disabled = false;
    });
}
// 1. Hàm xóa các mục đã tích chọn
function removeSelectedItems() {
    const selectedCheckboxes = document.querySelectorAll('.item-checkbox:checked');
    
    if (selectedCheckboxes.length === 0) {
        alert("Vui lòng chọn ít nhất một sản phẩm để xóa!");
        return;
    }

    if (!confirm("Bạn có chắc chắn muốn xóa các mục đã chọn khỏi giỏ hàng?")) return;

    // Lấy danh sách ID từ các hàng đã chọn
    const ids = Array.from(selectedCheckboxes).map(cb => cb.closest('.cart-row').dataset.id).join(',');

    const fd = new FormData();
    fd.append('ids', ids);
    fd.append('action', 'delete_selected');

    fetch('php/manage_cart.php', {
        method: 'POST',
        body: fd
    })
    .then(res => res.text())
    .then(data => {
        if (data.trim() === 'success') {
            location.reload();
        } else {
            alert("Lỗi: " + data);
        }
    });
}

// 2. Hàm xóa toàn bộ giỏ hàng
function removeAllCart() {
    if (!confirm("Cảnh báo: Bạn có chắc chắn muốn XÓA TẤT CẢ sản phẩm trong giỏ hàng không?")) return;

    const fd = new FormData();
    fd.append('action', 'delete_all');

    fetch('php/manage_cart.php', {
        method: 'POST',
        body: fd
    })
    .then(res => res.text())
    .then(data => {
        if (data.trim() === 'success') {
            location.reload();
        } else {
            alert("Lỗi: " + data);
        }
    });
}

// 3. Hàm xóa 1 mục duy nhất (Sửa lại hàm removeCartItem của bạn)
function removeCartItem(id) {
    if (!confirm("Xóa sản phẩm này khỏi giỏ hàng?")) return;

    const fd = new FormData();
    fd.append('ids', id);
    fd.append('action', 'delete_selected');

    fetch('php/manage_cart.php', {
        method: 'POST',
        body: fd
    })
    .then(res => res.text())
    .then(data => {
        if (data.trim() === 'success') {
            location.reload();
        } else {
            alert("Lỗi: " + data);
        }
    });
}
</script>
<footer id="footer" class="footer">
    <div class="container">
        <div class="footer-grid">
            <div class="footer-column">
                <h3 class="footer-title">HUNO SHOP</h3>
                <p class="footer-desc">
                    Định hình phong cách thời trang của bạn với những thiết kế dẫn đầu xu hướng và chất lượng cao cấp.
                </p>
                <ul class="footer-contact">
                    <li><i class="fa-solid fa-location-dot"></i> 456 Lê Lợi, Phường Bến Thành, Quận 1, Thành phố Hồ Chí Minh, Việt Nam.</li>
                    <li><i class="fa-solid fa-phone"></i> Chăm sóc khách hàng: 0246.2591551</li>
                    <li><i class="fa-solid fa-envelope"></i> Email: support@fashionshop.vn</li>
                </ul>
            </div>

            <div class="footer-column">
                <h3 class="footer-title">VỀ CHÚNG TÔI</h3>
                <ul class="footer-links">
                    <li><a href="about.html">Giới thiệu</a></li>
                    <li><a href="#">Triết lý kinh doanh</a></li>
                    <li><a href="#">Tin tức Fashion Blog</a></li>
                    <li><a href="#">Hệ thống cửa hàng</a></li>
                </ul>
            </div>

            <div class="footer-column">
                <h3 class="footer-title">CHÍNH SÁCH</h3>
                <ul class="footer-links">
                    <li><a href="#">Chính sách vận chuyển</a></li>
                    <li><a href="#">Hướng dẫn thanh toán</a></li>
                    <li><a href="#">Quy định đổi trả</a></li>
                    <li><a href="#">Bảo hành & Sửa chữa</a></li>
                </ul>
            </div>

            <div class="footer-column">
                <h3 class="footer-title">THANH TOÁN</h3>
                <div class="payment-methods">
                    <div class="payment-item" data-title="Tiền mặt">
                        <img src="img/logo/2.png" alt="Tiền mặt">
                    </div>

                    <div class="payment-item" data-title="Chuyển khoản">
                        <img src="img/logo/3.png" alt="Banking">
                    </div>
                </div>
                <div class="bct-logo" style="margin-top: 15px;">
                    <a href="#"><img src="https://theme.hstatic.net/200000182297/1000887316/14/bct.png?v=3066" width="120" alt="Đã thông báo Bộ Công Thương"></a>
                </div>
            </div>
        </div>
    </div>

    <div class="footer-bottom">
        <div class="container">
            <p>&copy; 2026 Huno Shop. Bản quyền thuộc về đội ngũ phát triển.</p>
        </div>
    </div>
</footer>
    </body>
    </html>